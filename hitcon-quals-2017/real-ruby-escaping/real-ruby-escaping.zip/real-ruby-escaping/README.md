Remote environment is fully-updated ubuntu 17.04.

Some information you may want to know:

```
$ uname -r
4.10.0-38-generic

$ /usr/bin/ruby --version
ruby 2.3.3p222 (2016-11-21) [x86_64-linux-gnu]

$ md5sum /usr/bin/ruby
46fbd9a932b9f191baa2ab4dd4adf43e  /usr/bin/ruby

$ cat server.sh
#!/bin/sh
nsjail --config nsjail.proto

$ md5sum /lib/x86_64-linux-gnu/libc-2.24.so
82ff57d04eb11340b072a4996e7bf89f  /lib/x86_64-linux-gnu/libc-2.24.so

```
