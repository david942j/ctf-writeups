# DTCAAS

```
$ git submodule status
 45f3d1a095dd3440578d5c6313eba555a791f3fb dtc (v1.6.1-30-g45f3d1a)
```

The binary was compiled with:
```
$ git apply dtc.patch
$ make
```
