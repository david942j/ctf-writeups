package android.support.constraint;

public final class R {

    public static final class attr {
        public static final int barrierAllowsGoneWidgets = 2130771968;
        public static final int barrierDirection = 2130771969;
        public static final int chainUseRtl = 2130771970;
        public static final int constraintSet = 2130771971;
        public static final int constraint_referenced_ids = 2130771972;
        public static final int content = 2130771973;
        public static final int emptyVisibility = 2130771974;
        public static final int layout_constrainedHeight = 2130771975;
        public static final int layout_constrainedWidth = 2130771976;
        public static final int layout_constraintBaseline_creator = 2130771977;
        public static final int layout_constraintBaseline_toBaselineOf = 2130771978;
        public static final int layout_constraintBottom_creator = 2130771979;
        public static final int layout_constraintBottom_toBottomOf = 2130771980;
        public static final int layout_constraintBottom_toTopOf = 2130771981;
        public static final int layout_constraintCircle = 2130771982;
        public static final int layout_constraintCircleAngle = 2130771983;
        public static final int layout_constraintCircleRadius = 2130771984;
        public static final int layout_constraintDimensionRatio = 2130771985;
        public static final int layout_constraintEnd_toEndOf = 2130771986;
        public static final int layout_constraintEnd_toStartOf = 2130771987;
        public static final int layout_constraintGuide_begin = 2130771988;
        public static final int layout_constraintGuide_end = 2130771989;
        public static final int layout_constraintGuide_percent = 2130771990;
        public static final int layout_constraintHeight_default = 2130771991;
        public static final int layout_constraintHeight_max = 2130771992;
        public static final int layout_constraintHeight_min = 2130771993;
        public static final int layout_constraintHeight_percent = 2130771994;
        public static final int layout_constraintHorizontal_bias = 2130771995;
        public static final int layout_constraintHorizontal_chainStyle = 2130771996;
        public static final int layout_constraintHorizontal_weight = 2130771997;
        public static final int layout_constraintLeft_creator = 2130771998;
        public static final int layout_constraintLeft_toLeftOf = 2130771999;
        public static final int layout_constraintLeft_toRightOf = 2130772000;
        public static final int layout_constraintRight_creator = 2130772001;
        public static final int layout_constraintRight_toLeftOf = 2130772002;
        public static final int layout_constraintRight_toRightOf = 2130772003;
        public static final int layout_constraintStart_toEndOf = 2130772004;
        public static final int layout_constraintStart_toStartOf = 2130772005;
        public static final int layout_constraintTop_creator = 2130772006;
        public static final int layout_constraintTop_toBottomOf = 2130772007;
        public static final int layout_constraintTop_toTopOf = 2130772008;
        public static final int layout_constraintVertical_bias = 2130772009;
        public static final int layout_constraintVertical_chainStyle = 2130772010;
        public static final int layout_constraintVertical_weight = 2130772011;
        public static final int layout_constraintWidth_default = 2130772012;
        public static final int layout_constraintWidth_max = 2130772013;
        public static final int layout_constraintWidth_min = 2130772014;
        public static final int layout_constraintWidth_percent = 2130772015;
        public static final int layout_editor_absoluteX = 2130772016;
        public static final int layout_editor_absoluteY = 2130772017;
        public static final int layout_goneMarginBottom = 2130772018;
        public static final int layout_goneMarginEnd = 2130772019;
        public static final int layout_goneMarginLeft = 2130772020;
        public static final int layout_goneMarginRight = 2130772021;
        public static final int layout_goneMarginStart = 2130772022;
        public static final int layout_goneMarginTop = 2130772023;
        public static final int layout_optimizationLevel = 2130772024;

        private attr() {
        }
    }

    public static final class id {
        public static final int bottom = 2131034113;
        public static final int end = 2131034120;
        public static final int gone = 2131034121;
        public static final int invisible = 2131034123;
        public static final int left = 2131034124;
        public static final int packed = 2131034126;
        public static final int parent = 2131034127;
        public static final int percent = 2131034128;
        public static final int right = 2131034129;
        public static final int spread = 2131034130;
        public static final int spread_inside = 2131034131;
        public static final int start = 2131034133;
        public static final int top = 2131034134;
        public static final int wrap = 2131034135;

        private id() {
        }
    }

    public static final class styleable {
        public static final int[] ConstraintLayout_Layout = new int[]{16842948, 16843039, 16843040, 16843071, 16843072, ooo.defcon2019.quals.veryandroidoso.R.attr.barrierAllowsGoneWidgets, ooo.defcon2019.quals.veryandroidoso.R.attr.barrierDirection, ooo.defcon2019.quals.veryandroidoso.R.attr.chainUseRtl, ooo.defcon2019.quals.veryandroidoso.R.attr.constraintSet, ooo.defcon2019.quals.veryandroidoso.R.attr.constraint_referenced_ids, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constrainedHeight, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constrainedWidth, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintBaseline_creator, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintBaseline_toBaselineOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintBottom_creator, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintBottom_toBottomOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintBottom_toTopOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintCircle, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintCircleAngle, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintCircleRadius, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintDimensionRatio, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintEnd_toEndOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintEnd_toStartOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintGuide_begin, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintGuide_end, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintGuide_percent, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHeight_default, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHeight_max, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHeight_min, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHeight_percent, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHorizontal_bias, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHorizontal_chainStyle, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHorizontal_weight, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintLeft_creator, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintLeft_toLeftOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintLeft_toRightOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintRight_creator, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintRight_toLeftOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintRight_toRightOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintStart_toEndOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintStart_toStartOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintTop_creator, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintTop_toBottomOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintTop_toTopOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintVertical_bias, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintVertical_chainStyle, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintVertical_weight, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintWidth_default, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintWidth_max, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintWidth_min, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintWidth_percent, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_editor_absoluteX, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_editor_absoluteY, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginBottom, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginEnd, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginLeft, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginRight, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginStart, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginTop, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_optimizationLevel};
        public static final int ConstraintLayout_Layout_android_maxHeight = 2;
        public static final int ConstraintLayout_Layout_android_maxWidth = 1;
        public static final int ConstraintLayout_Layout_android_minHeight = 4;
        public static final int ConstraintLayout_Layout_android_minWidth = 3;
        public static final int ConstraintLayout_Layout_android_orientation = 0;
        public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 5;
        public static final int ConstraintLayout_Layout_barrierDirection = 6;
        public static final int ConstraintLayout_Layout_chainUseRtl = 7;
        public static final int ConstraintLayout_Layout_constraintSet = 8;
        public static final int ConstraintLayout_Layout_constraint_referenced_ids = 9;
        public static final int ConstraintLayout_Layout_layout_constrainedHeight = 10;
        public static final int ConstraintLayout_Layout_layout_constrainedWidth = 11;
        public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 12;
        public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 13;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 14;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 15;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 16;
        public static final int ConstraintLayout_Layout_layout_constraintCircle = 17;
        public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 18;
        public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 19;
        public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 20;
        public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 21;
        public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 22;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 23;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 24;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 25;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 26;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 27;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 28;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 29;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 30;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 31;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 32;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 33;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 34;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 35;
        public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 36;
        public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 37;
        public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 38;
        public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 39;
        public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 40;
        public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 41;
        public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 42;
        public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 43;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 44;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 45;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 46;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 47;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 48;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 49;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 50;
        public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 51;
        public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 52;
        public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 53;
        public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 54;
        public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 55;
        public static final int ConstraintLayout_Layout_layout_goneMarginRight = 56;
        public static final int ConstraintLayout_Layout_layout_goneMarginStart = 57;
        public static final int ConstraintLayout_Layout_layout_goneMarginTop = 58;
        public static final int ConstraintLayout_Layout_layout_optimizationLevel = 59;
        public static final int[] ConstraintLayout_placeholder = new int[]{ooo.defcon2019.quals.veryandroidoso.R.attr.content, ooo.defcon2019.quals.veryandroidoso.R.attr.emptyVisibility};
        public static final int ConstraintLayout_placeholder_content = 0;
        public static final int ConstraintLayout_placeholder_emptyVisibility = 1;
        public static final int[] ConstraintSet = new int[]{16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, ooo.defcon2019.quals.veryandroidoso.R.attr.barrierAllowsGoneWidgets, ooo.defcon2019.quals.veryandroidoso.R.attr.barrierDirection, ooo.defcon2019.quals.veryandroidoso.R.attr.chainUseRtl, ooo.defcon2019.quals.veryandroidoso.R.attr.constraint_referenced_ids, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constrainedHeight, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constrainedWidth, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintBaseline_creator, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintBaseline_toBaselineOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintBottom_creator, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintBottom_toBottomOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintBottom_toTopOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintCircle, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintCircleAngle, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintCircleRadius, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintDimensionRatio, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintEnd_toEndOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintEnd_toStartOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintGuide_begin, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintGuide_end, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintGuide_percent, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHeight_default, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHeight_max, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHeight_min, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHeight_percent, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHorizontal_bias, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHorizontal_chainStyle, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintHorizontal_weight, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintLeft_creator, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintLeft_toLeftOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintLeft_toRightOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintRight_creator, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintRight_toLeftOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintRight_toRightOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintStart_toEndOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintStart_toStartOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintTop_creator, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintTop_toBottomOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintTop_toTopOf, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintVertical_bias, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintVertical_chainStyle, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintVertical_weight, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintWidth_default, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintWidth_max, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintWidth_min, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_constraintWidth_percent, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_editor_absoluteX, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_editor_absoluteY, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginBottom, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginEnd, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginLeft, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginRight, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginStart, ooo.defcon2019.quals.veryandroidoso.R.attr.layout_goneMarginTop};
        public static final int ConstraintSet_android_alpha = 13;
        public static final int ConstraintSet_android_elevation = 26;
        public static final int ConstraintSet_android_id = 1;
        public static final int ConstraintSet_android_layout_height = 4;
        public static final int ConstraintSet_android_layout_marginBottom = 8;
        public static final int ConstraintSet_android_layout_marginEnd = 24;
        public static final int ConstraintSet_android_layout_marginLeft = 5;
        public static final int ConstraintSet_android_layout_marginRight = 7;
        public static final int ConstraintSet_android_layout_marginStart = 23;
        public static final int ConstraintSet_android_layout_marginTop = 6;
        public static final int ConstraintSet_android_layout_width = 3;
        public static final int ConstraintSet_android_maxHeight = 10;
        public static final int ConstraintSet_android_maxWidth = 9;
        public static final int ConstraintSet_android_minHeight = 12;
        public static final int ConstraintSet_android_minWidth = 11;
        public static final int ConstraintSet_android_orientation = 0;
        public static final int ConstraintSet_android_rotation = 20;
        public static final int ConstraintSet_android_rotationX = 21;
        public static final int ConstraintSet_android_rotationY = 22;
        public static final int ConstraintSet_android_scaleX = 18;
        public static final int ConstraintSet_android_scaleY = 19;
        public static final int ConstraintSet_android_transformPivotX = 14;
        public static final int ConstraintSet_android_transformPivotY = 15;
        public static final int ConstraintSet_android_translationX = 16;
        public static final int ConstraintSet_android_translationY = 17;
        public static final int ConstraintSet_android_translationZ = 25;
        public static final int ConstraintSet_android_visibility = 2;
        public static final int ConstraintSet_barrierAllowsGoneWidgets = 27;
        public static final int ConstraintSet_barrierDirection = 28;
        public static final int ConstraintSet_chainUseRtl = 29;
        public static final int ConstraintSet_constraint_referenced_ids = 30;
        public static final int ConstraintSet_layout_constrainedHeight = 31;
        public static final int ConstraintSet_layout_constrainedWidth = 32;
        public static final int ConstraintSet_layout_constraintBaseline_creator = 33;
        public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 34;
        public static final int ConstraintSet_layout_constraintBottom_creator = 35;
        public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 36;
        public static final int ConstraintSet_layout_constraintBottom_toTopOf = 37;
        public static final int ConstraintSet_layout_constraintCircle = 38;
        public static final int ConstraintSet_layout_constraintCircleAngle = 39;
        public static final int ConstraintSet_layout_constraintCircleRadius = 40;
        public static final int ConstraintSet_layout_constraintDimensionRatio = 41;
        public static final int ConstraintSet_layout_constraintEnd_toEndOf = 42;
        public static final int ConstraintSet_layout_constraintEnd_toStartOf = 43;
        public static final int ConstraintSet_layout_constraintGuide_begin = 44;
        public static final int ConstraintSet_layout_constraintGuide_end = 45;
        public static final int ConstraintSet_layout_constraintGuide_percent = 46;
        public static final int ConstraintSet_layout_constraintHeight_default = 47;
        public static final int ConstraintSet_layout_constraintHeight_max = 48;
        public static final int ConstraintSet_layout_constraintHeight_min = 49;
        public static final int ConstraintSet_layout_constraintHeight_percent = 50;
        public static final int ConstraintSet_layout_constraintHorizontal_bias = 51;
        public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 52;
        public static final int ConstraintSet_layout_constraintHorizontal_weight = 53;
        public static final int ConstraintSet_layout_constraintLeft_creator = 54;
        public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 55;
        public static final int ConstraintSet_layout_constraintLeft_toRightOf = 56;
        public static final int ConstraintSet_layout_constraintRight_creator = 57;
        public static final int ConstraintSet_layout_constraintRight_toLeftOf = 58;
        public static final int ConstraintSet_layout_constraintRight_toRightOf = 59;
        public static final int ConstraintSet_layout_constraintStart_toEndOf = 60;
        public static final int ConstraintSet_layout_constraintStart_toStartOf = 61;
        public static final int ConstraintSet_layout_constraintTop_creator = 62;
        public static final int ConstraintSet_layout_constraintTop_toBottomOf = 63;
        public static final int ConstraintSet_layout_constraintTop_toTopOf = 64;
        public static final int ConstraintSet_layout_constraintVertical_bias = 65;
        public static final int ConstraintSet_layout_constraintVertical_chainStyle = 66;
        public static final int ConstraintSet_layout_constraintVertical_weight = 67;
        public static final int ConstraintSet_layout_constraintWidth_default = 68;
        public static final int ConstraintSet_layout_constraintWidth_max = 69;
        public static final int ConstraintSet_layout_constraintWidth_min = 70;
        public static final int ConstraintSet_layout_constraintWidth_percent = 71;
        public static final int ConstraintSet_layout_editor_absoluteX = 72;
        public static final int ConstraintSet_layout_editor_absoluteY = 73;
        public static final int ConstraintSet_layout_goneMarginBottom = 74;
        public static final int ConstraintSet_layout_goneMarginEnd = 75;
        public static final int ConstraintSet_layout_goneMarginLeft = 76;
        public static final int ConstraintSet_layout_goneMarginRight = 77;
        public static final int ConstraintSet_layout_goneMarginStart = 78;
        public static final int ConstraintSet_layout_goneMarginTop = 79;
        public static final int[] LinearConstraintLayout = new int[]{16842948};
        public static final int LinearConstraintLayout_android_orientation = 0;

        private styleable() {
        }
    }

    private R() {
    }
}
