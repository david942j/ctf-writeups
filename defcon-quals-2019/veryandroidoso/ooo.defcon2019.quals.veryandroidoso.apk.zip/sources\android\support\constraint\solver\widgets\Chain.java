package android.support.constraint.solver.widgets;

import android.support.constraint.solver.ArrayRow;
import android.support.constraint.solver.LinearSystem;
import android.support.constraint.solver.SolverVariable;
import android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour;
import java.util.ArrayList;

class Chain {
    private static final boolean DEBUG = false;

    Chain() {
    }

    static void applyChainConstraints(ConstraintWidgetContainer constraintWidgetContainer, LinearSystem linearSystem, int i) {
        int i2;
        ChainHead[] chainHeadArr;
        int i3;
        int i4 = 0;
        if (i == 0) {
            i2 = constraintWidgetContainer.mHorizontalChainsSize;
            chainHeadArr = constraintWidgetContainer.mHorizontalChainsArray;
            i3 = i2;
            i2 = 0;
        } else {
            i2 = 2;
            int i5 = constraintWidgetContainer.mVerticalChainsSize;
            i3 = i5;
            chainHeadArr = constraintWidgetContainer.mVerticalChainsArray;
        }
        while (i4 < i3) {
            ChainHead chainHead = chainHeadArr[i4];
            chainHead.define();
            if (!constraintWidgetContainer.optimizeFor(4)) {
                applyChainConstraints(constraintWidgetContainer, linearSystem, i, i2, chainHead);
            } else if (!Optimizer.applyChainOptimized(constraintWidgetContainer, linearSystem, i, i2, chainHead)) {
                applyChainConstraints(constraintWidgetContainer, linearSystem, i, i2, chainHead);
            }
            i4++;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:85:0x0167  */
    /* JADX WARNING: Removed duplicated region for block: B:88:0x0185  */
    /* JADX WARNING: Removed duplicated region for block: B:207:0x03c6  */
    /* JADX WARNING: Removed duplicated region for block: B:260:0x04d2  */
    /* JADX WARNING: Removed duplicated region for block: B:255:0x049d  */
    /* JADX WARNING: Removed duplicated region for block: B:270:0x04fc  */
    /* JADX WARNING: Removed duplicated region for block: B:269:0x04f7  */
    /* JADX WARNING: Removed duplicated region for block: B:274:0x0507  */
    /* JADX WARNING: Removed duplicated region for block: B:273:0x0502  */
    /* JADX WARNING: Removed duplicated region for block: B:281:0x051c  */
    /* JADX WARNING: Removed duplicated region for block: B:276:0x050b  */
    /* JADX WARNING: Removed duplicated region for block: B:283:0x051f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void applyChainConstraints(ConstraintWidgetContainer constraintWidgetContainer, LinearSystem linearSystem, int i, int i2, ChainHead chainHead) {
        Object obj;
        ConstraintWidget constraintWidget;
        Object obj2;
        Object obj3;
        Object obj4;
        int margin;
        float f;
        int i3;
        Object obj5;
        ConstraintWidget constraintWidget2;
        int i4;
        ConstraintAnchor constraintAnchor;
        int i5;
        ArrayList arrayList;
        ConstraintWidget constraintWidget3;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor3;
        SolverVariable solverVariable;
        int i6;
        Object obj6;
        ConstraintWidget constraintWidget4;
        int i7;
        ConstraintAnchor constraintAnchor4;
        ConstraintAnchor constraintAnchor5;
        SolverVariable solverVariable2;
        ConstraintWidgetContainer constraintWidgetContainer2 = constraintWidgetContainer;
        LinearSystem linearSystem2 = linearSystem;
        ChainHead chainHead2 = chainHead;
        ConstraintWidget constraintWidget5 = chainHead2.mFirst;
        ConstraintWidget constraintWidget6 = chainHead2.mLast;
        ConstraintWidget constraintWidget7 = chainHead2.mFirstVisibleWidget;
        ConstraintWidget constraintWidget8 = chainHead2.mLastVisibleWidget;
        ConstraintWidget constraintWidget9 = chainHead2.mHead;
        float f2 = chainHead2.mTotalWeight;
        ConstraintWidget constraintWidget10 = chainHead2.mFirstMatchConstraintWidget;
        constraintWidget10 = chainHead2.mLastMatchConstraintWidget;
        Object obj7 = constraintWidgetContainer2.mListDimensionBehaviors[i] == DimensionBehaviour.WRAP_CONTENT ? 1 : null;
        if (i == 0) {
            obj = constraintWidget9.mHorizontalChainStyle == 0 ? 1 : null;
            constraintWidget = constraintWidget5;
            obj2 = constraintWidget9.mHorizontalChainStyle == 1 ? 1 : null;
            obj3 = constraintWidget9.mHorizontalChainStyle == 2 ? 1 : null;
            obj4 = null;
        } else {
            obj = constraintWidget9.mVerticalChainStyle == 0 ? 1 : null;
            constraintWidget = constraintWidget5;
            obj2 = constraintWidget9.mVerticalChainStyle == 1 ? 1 : null;
            obj3 = constraintWidget9.mVerticalChainStyle == 2 ? 1 : null;
            obj4 = null;
        }
        while (true) {
            ConstraintWidget constraintWidget11 = null;
            if (obj4 != null) {
                break;
            }
            Object obj8;
            ConstraintAnchor constraintAnchor6 = constraintWidget.mListAnchors[i2];
            int i8 = (obj7 == null && obj3 == null) ? 4 : 1;
            int margin2 = constraintAnchor6.getMargin();
            margin = (constraintAnchor6.mTarget == null || constraintWidget == constraintWidget5) ? margin2 : margin2 + constraintAnchor6.mTarget.getMargin();
            if (obj3 != null && constraintWidget != constraintWidget5 && constraintWidget != constraintWidget7) {
                f = f2;
                obj8 = obj4;
                i3 = 6;
            } else if (obj == null || obj7 == null) {
                f = f2;
                i3 = i8;
                obj8 = obj4;
            } else {
                f = f2;
                obj8 = obj4;
                i3 = 4;
            }
            if (constraintAnchor6.mTarget != null) {
                if (constraintWidget == constraintWidget7) {
                    obj5 = obj;
                    constraintWidget2 = constraintWidget9;
                    linearSystem2.addGreaterThan(constraintAnchor6.mSolverVariable, constraintAnchor6.mTarget.mSolverVariable, margin, 5);
                } else {
                    constraintWidget2 = constraintWidget9;
                    obj5 = obj;
                    linearSystem2.addGreaterThan(constraintAnchor6.mSolverVariable, constraintAnchor6.mTarget.mSolverVariable, margin, 6);
                }
                linearSystem2.addEquality(constraintAnchor6.mSolverVariable, constraintAnchor6.mTarget.mSolverVariable, margin, i3);
            } else {
                constraintWidget2 = constraintWidget9;
                obj5 = obj;
            }
            if (obj7 != null) {
                if (constraintWidget.getVisibility() == 8 || constraintWidget.mListDimensionBehaviors[i] != DimensionBehaviour.MATCH_CONSTRAINT) {
                    i4 = 0;
                } else {
                    i4 = 0;
                    linearSystem2.addGreaterThan(constraintWidget.mListAnchors[i2 + 1].mSolverVariable, constraintWidget.mListAnchors[i2].mSolverVariable, 0, 5);
                }
                linearSystem2.addGreaterThan(constraintWidget.mListAnchors[i2].mSolverVariable, constraintWidgetContainer2.mListAnchors[i2].mSolverVariable, i4, 6);
            }
            constraintAnchor = constraintWidget.mListAnchors[i2 + 1].mTarget;
            if (constraintAnchor != null) {
                constraintWidget9 = constraintAnchor.mOwner;
                if (constraintWidget9.mListAnchors[i2].mTarget != null && constraintWidget9.mListAnchors[i2].mTarget.mOwner == constraintWidget) {
                    constraintWidget11 = constraintWidget9;
                }
            }
            if (constraintWidget11 != null) {
                constraintWidget = constraintWidget11;
                obj4 = obj8;
            } else {
                obj4 = 1;
            }
            f2 = f;
            obj = obj5;
            constraintWidget9 = constraintWidget2;
        }
        constraintWidget2 = constraintWidget9;
        f = f2;
        obj5 = obj;
        if (constraintWidget8 != null) {
            i3 = i2 + 1;
            if (constraintWidget6.mListAnchors[i3].mTarget != null) {
                float f3;
                int i9;
                int i10;
                SolverVariable solverVariable3;
                SolverVariable solverVariable4;
                SolverVariable solverVariable5;
                constraintAnchor = constraintWidget8.mListAnchors[i3];
                linearSystem2.addLowerThan(constraintAnchor.mSolverVariable, constraintWidget6.mListAnchors[i3].mTarget.mSolverVariable, -constraintAnchor.getMargin(), 5);
                if (obj7 != null) {
                    i5 = i2 + 1;
                    linearSystem2.addGreaterThan(constraintWidgetContainer2.mListAnchors[i5].mSolverVariable, constraintWidget6.mListAnchors[i5].mSolverVariable, constraintWidget6.mListAnchors[i5].getMargin(), 6);
                }
                arrayList = chainHead2.mWeightedMatchConstraintsWidgets;
                if (arrayList != null) {
                    i5 = arrayList.size();
                    if (i5 > 1) {
                        f3 = (!chainHead2.mHasUndefinedWeights || chainHead2.mHasComplexMatchWeights) ? f : (float) chainHead2.mWidgetsMatchCount;
                        float f4 = 0.0f;
                        constraintWidget = null;
                        i9 = 0;
                        float f5 = 0.0f;
                        while (i9 < i5) {
                            float f6;
                            ArrayList arrayList2;
                            constraintWidget3 = (ConstraintWidget) arrayList.get(i9);
                            f2 = constraintWidget3.mWeight[i];
                            if (f2 >= f4) {
                                f6 = 0.0f;
                            } else if (chainHead2.mHasComplexMatchWeights) {
                                linearSystem2.addEquality(constraintWidget3.mListAnchors[i2 + 1].mSolverVariable, constraintWidget3.mListAnchors[i2].mSolverVariable, 0, 4);
                                arrayList2 = arrayList;
                                i10 = i5;
                                i9++;
                                i5 = i10;
                                arrayList = arrayList2;
                                f4 = 0.0f;
                            } else {
                                f2 = 1.0f;
                                f6 = 0.0f;
                            }
                            if (f2 == f6) {
                                linearSystem2.addEquality(constraintWidget3.mListAnchors[i2 + 1].mSolverVariable, constraintWidget3.mListAnchors[i2].mSolverVariable, 0, 6);
                                arrayList2 = arrayList;
                                i10 = i5;
                                i9++;
                                i5 = i10;
                                arrayList = arrayList2;
                                f4 = 0.0f;
                            } else {
                                if (constraintWidget != null) {
                                    solverVariable3 = constraintWidget.mListAnchors[i2].mSolverVariable;
                                    i10 = i2 + 1;
                                    solverVariable4 = constraintWidget.mListAnchors[i10].mSolverVariable;
                                    solverVariable5 = constraintWidget3.mListAnchors[i2].mSolverVariable;
                                    arrayList2 = arrayList;
                                    SolverVariable solverVariable6 = constraintWidget3.mListAnchors[i10].mSolverVariable;
                                    i10 = i5;
                                    ArrayRow createRow = linearSystem.createRow();
                                    createRow.createRowEqualMatchDimensions(f5, f3, f2, solverVariable3, solverVariable4, solverVariable5, solverVariable6);
                                    linearSystem2.addConstraint(createRow);
                                } else {
                                    arrayList2 = arrayList;
                                    i10 = i5;
                                }
                                f5 = f2;
                                constraintWidget = constraintWidget3;
                                i9++;
                                i5 = i10;
                                arrayList = arrayList2;
                                f4 = 0.0f;
                            }
                        }
                    }
                }
                ConstraintWidget constraintWidget12;
                SolverVariable solverVariable7;
                SolverVariable solverVariable8;
                int margin3;
                int margin4;
                ConstraintAnchor constraintAnchor7;
                int margin5;
                if (constraintWidget7 == null && (constraintWidget7 == constraintWidget8 || obj3 != null)) {
                    constraintAnchor2 = constraintWidget5.mListAnchors[i2];
                    i5 = i2 + 1;
                    constraintAnchor3 = constraintWidget6.mListAnchors[i5];
                    solverVariable = constraintWidget5.mListAnchors[i2].mTarget != null ? constraintWidget5.mListAnchors[i2].mTarget.mSolverVariable : null;
                    solverVariable3 = constraintWidget6.mListAnchors[i5].mTarget != null ? constraintWidget6.mListAnchors[i5].mTarget.mSolverVariable : null;
                    if (constraintWidget7 == constraintWidget8) {
                        constraintAnchor2 = constraintWidget7.mListAnchors[i2];
                        constraintAnchor3 = constraintWidget7.mListAnchors[i5];
                    }
                    if (!(solverVariable == null || solverVariable3 == null)) {
                        if (i == 0) {
                            f3 = constraintWidget2.mHorizontalBiasPercent;
                        } else {
                            f3 = constraintWidget2.mVerticalBiasPercent;
                        }
                        linearSystem.addCentering(constraintAnchor2.mSolverVariable, solverVariable, constraintAnchor2.getMargin(), f3, solverVariable3, constraintAnchor3.mSolverVariable, constraintAnchor3.getMargin(), 5);
                    }
                } else if (obj5 != null || constraintWidget7 == null) {
                    i6 = 8;
                    if (!(obj2 == null || constraintWidget7 == null)) {
                        obj6 = (chainHead2.mWidgetsMatchCount > 0 || chainHead2.mWidgetsCount != chainHead2.mWidgetsMatchCount) ? null : 1;
                        constraintWidget4 = constraintWidget7;
                        constraintWidget3 = constraintWidget4;
                        while (constraintWidget4 != null) {
                            ConstraintWidget constraintWidget13 = constraintWidget4.mNextChainWidget[i];
                            while (constraintWidget13 != null && constraintWidget13.getVisibility() == i6) {
                                constraintWidget13 = constraintWidget13.mNextChainWidget[i];
                            }
                            if (constraintWidget4 == constraintWidget7 || constraintWidget4 == constraintWidget8 || constraintWidget13 == null) {
                                constraintWidget12 = constraintWidget3;
                                i7 = 8;
                            } else {
                                ConstraintWidget constraintWidget14;
                                ConstraintWidget constraintWidget15 = constraintWidget13 == constraintWidget8 ? null : constraintWidget13;
                                constraintAnchor2 = constraintWidget4.mListAnchors[i2];
                                solverVariable7 = constraintAnchor2.mSolverVariable;
                                if (constraintAnchor2.mTarget != null) {
                                    solverVariable8 = constraintAnchor2.mTarget.mSolverVariable;
                                }
                                i3 = i2 + 1;
                                solverVariable8 = constraintWidget3.mListAnchors[i3].mSolverVariable;
                                margin3 = constraintAnchor2.getMargin();
                                margin4 = constraintWidget4.mListAnchors[i3].getMargin();
                                if (constraintWidget15 != null) {
                                    constraintAnchor7 = constraintWidget15.mListAnchors[i2];
                                    solverVariable5 = constraintAnchor7.mSolverVariable;
                                    solverVariable4 = constraintAnchor7.mTarget != null ? constraintAnchor7.mTarget.mSolverVariable : null;
                                } else {
                                    constraintAnchor7 = constraintWidget4.mListAnchors[i3].mTarget;
                                    solverVariable5 = constraintAnchor7 != null ? constraintAnchor7.mSolverVariable : null;
                                    solverVariable4 = constraintWidget4.mListAnchors[i3].mSolverVariable;
                                }
                                margin5 = constraintAnchor7 != null ? margin4 + constraintAnchor7.getMargin() : margin4;
                                i3 = constraintWidget3 != null ? margin3 + constraintWidget3.mListAnchors[i3].getMargin() : margin3;
                                i10 = obj6 != null ? 6 : 4;
                                if (solverVariable7 == null || solverVariable8 == null || solverVariable5 == null || solverVariable4 == null) {
                                    constraintWidget14 = constraintWidget15;
                                    constraintWidget12 = constraintWidget3;
                                    i7 = 8;
                                } else {
                                    constraintWidget14 = constraintWidget15;
                                    i9 = margin5;
                                    constraintWidget12 = constraintWidget3;
                                    i7 = 8;
                                    linearSystem.addCentering(solverVariable7, solverVariable8, i3, 0.5f, solverVariable5, solverVariable4, i9, i10);
                                }
                                constraintWidget13 = constraintWidget14;
                            }
                            if (constraintWidget4.getVisibility() == i7) {
                                constraintWidget4 = constraintWidget12;
                            }
                            constraintWidget3 = constraintWidget4;
                            i6 = 8;
                            constraintWidget4 = constraintWidget13;
                        }
                        constraintAnchor2 = constraintWidget7.mListAnchors[i2];
                        constraintAnchor3 = constraintWidget5.mListAnchors[i2].mTarget;
                        i3 = i2 + 1;
                        constraintAnchor4 = constraintWidget8.mListAnchors[i3];
                        constraintAnchor5 = constraintWidget6.mListAnchors[i3].mTarget;
                        if (constraintAnchor3 != null) {
                            i7 = 5;
                        } else if (constraintWidget7 != constraintWidget8) {
                            i7 = 5;
                            linearSystem2.addEquality(constraintAnchor2.mSolverVariable, constraintAnchor3.mSolverVariable, constraintAnchor2.getMargin(), 5);
                        } else {
                            i7 = 5;
                            if (constraintAnchor5 != null) {
                                linearSystem.addCentering(constraintAnchor2.mSolverVariable, constraintAnchor3.mSolverVariable, constraintAnchor2.getMargin(), 0.5f, constraintAnchor4.mSolverVariable, constraintAnchor5.mSolverVariable, constraintAnchor4.getMargin(), 5);
                            }
                        }
                        if (!(constraintAnchor5 == null || constraintWidget7 == constraintWidget8)) {
                            linearSystem2.addEquality(constraintAnchor4.mSolverVariable, constraintAnchor5.mSolverVariable, -constraintAnchor4.getMargin(), i7);
                        }
                    }
                } else {
                    obj6 = (chainHead2.mWidgetsMatchCount <= 0 || chainHead2.mWidgetsCount != chainHead2.mWidgetsMatchCount) ? null : 1;
                    constraintWidget4 = constraintWidget7;
                    constraintWidget3 = constraintWidget4;
                    while (constraintWidget4 != null) {
                        constraintWidget = constraintWidget4.mNextChainWidget[i];
                        while (constraintWidget != null) {
                            if (constraintWidget.getVisibility() != 8) {
                                break;
                            }
                            constraintWidget = constraintWidget.mNextChainWidget[i];
                        }
                        if (constraintWidget != null || constraintWidget4 == constraintWidget8) {
                            SolverVariable solverVariable9;
                            constraintAnchor2 = constraintWidget4.mListAnchors[i2];
                            solverVariable7 = constraintAnchor2.mSolverVariable;
                            solverVariable8 = constraintAnchor2.mTarget != null ? constraintAnchor2.mTarget.mSolverVariable : null;
                            if (constraintWidget3 != constraintWidget4) {
                                solverVariable8 = constraintWidget3.mListAnchors[i2 + 1].mSolverVariable;
                            } else if (constraintWidget4 == constraintWidget7 && constraintWidget3 == constraintWidget4) {
                                solverVariable8 = constraintWidget5.mListAnchors[i2].mTarget != null ? constraintWidget5.mListAnchors[i2].mTarget.mSolverVariable : null;
                            }
                            margin3 = constraintAnchor2.getMargin();
                            margin4 = i2 + 1;
                            i3 = constraintWidget4.mListAnchors[margin4].getMargin();
                            if (constraintWidget != null) {
                                constraintAnchor7 = constraintWidget.mListAnchors[i2];
                                solverVariable5 = constraintAnchor7.mSolverVariable;
                                solverVariable9 = constraintWidget4.mListAnchors[margin4].mSolverVariable;
                            } else {
                                constraintAnchor7 = constraintWidget6.mListAnchors[margin4].mTarget;
                                solverVariable5 = constraintAnchor7 != null ? constraintAnchor7.mSolverVariable : null;
                                solverVariable9 = constraintWidget4.mListAnchors[margin4].mSolverVariable;
                            }
                            if (constraintAnchor7 != null) {
                                i3 += constraintAnchor7.getMargin();
                            }
                            if (constraintWidget3 != null) {
                                margin3 += constraintWidget3.mListAnchors[margin4].getMargin();
                            }
                            if (solverVariable7 == null || solverVariable8 == null || solverVariable5 == null || solverVariable9 == null) {
                                constraintWidget12 = constraintWidget;
                            } else {
                                i4 = constraintWidget4 == constraintWidget7 ? constraintWidget7.mListAnchors[i2].getMargin() : margin3;
                                margin5 = constraintWidget4 == constraintWidget8 ? constraintWidget8.mListAnchors[margin4].getMargin() : i3;
                                i3 = i4;
                                solverVariable3 = solverVariable5;
                                solverVariable5 = solverVariable9;
                                i9 = margin5;
                                constraintWidget12 = constraintWidget;
                                linearSystem.addCentering(solverVariable7, solverVariable8, i3, 0.5f, solverVariable3, solverVariable5, i9, obj6 != null ? 6 : 4);
                            }
                        } else {
                            constraintWidget12 = constraintWidget;
                        }
                        if (constraintWidget4.getVisibility() != 8) {
                            constraintWidget3 = constraintWidget4;
                        }
                        constraintWidget4 = constraintWidget12;
                    }
                }
                if ((obj5 == null || obj2 != null) && constraintWidget7 != null) {
                    constraintAnchor2 = constraintWidget7.mListAnchors[i2];
                    i5 = i2 + 1;
                    constraintAnchor3 = constraintWidget8.mListAnchors[i5];
                    solverVariable = constraintAnchor2.mTarget == null ? constraintAnchor2.mTarget.mSolverVariable : null;
                    solverVariable2 = constraintAnchor3.mTarget == null ? constraintAnchor3.mTarget.mSolverVariable : null;
                    if (constraintWidget6 == constraintWidget8) {
                        ConstraintAnchor constraintAnchor8 = constraintWidget6.mListAnchors[i5];
                        solverVariable3 = constraintAnchor8.mTarget != null ? constraintAnchor8.mTarget.mSolverVariable : null;
                    } else {
                        solverVariable3 = solverVariable2;
                    }
                    if (constraintWidget7 == constraintWidget8) {
                        constraintAnchor2 = constraintWidget7.mListAnchors[i2];
                        constraintAnchor3 = constraintWidget7.mListAnchors[i5];
                    }
                    if (solverVariable != null && solverVariable3 != null) {
                        margin = constraintAnchor2.getMargin();
                        if (constraintWidget8 != null) {
                            constraintWidget6 = constraintWidget8;
                        }
                        linearSystem.addCentering(constraintAnchor2.mSolverVariable, solverVariable, margin, 0.5f, solverVariable3, constraintAnchor3.mSolverVariable, constraintWidget6.mListAnchors[i5].getMargin(), 5);
                        return;
                    }
                }
                return;
            }
        }
        if (obj7 != null) {
        }
        arrayList = chainHead2.mWeightedMatchConstraintsWidgets;
        if (arrayList != null) {
        }
        if (constraintWidget7 == null) {
        }
        if (obj5 != null) {
        }
        i6 = 8;
        if (chainHead2.mWidgetsMatchCount > 0) {
        }
        constraintWidget4 = constraintWidget7;
        constraintWidget3 = constraintWidget4;
        while (constraintWidget4 != null) {
        }
        constraintAnchor2 = constraintWidget7.mListAnchors[i2];
        constraintAnchor3 = constraintWidget5.mListAnchors[i2].mTarget;
        i3 = i2 + 1;
        constraintAnchor4 = constraintWidget8.mListAnchors[i3];
        constraintAnchor5 = constraintWidget6.mListAnchors[i3].mTarget;
        if (constraintAnchor3 != null) {
        }
        linearSystem2.addEquality(constraintAnchor4.mSolverVariable, constraintAnchor5.mSolverVariable, -constraintAnchor4.getMargin(), i7);
        if (obj5 == null) {
        }
        constraintAnchor2 = constraintWidget7.mListAnchors[i2];
        i5 = i2 + 1;
        constraintAnchor3 = constraintWidget8.mListAnchors[i5];
        if (constraintAnchor2.mTarget == null) {
        }
        if (constraintAnchor3.mTarget == null) {
        }
        if (constraintWidget6 == constraintWidget8) {
        }
        if (constraintWidget7 == constraintWidget8) {
        }
        if (solverVariable != null) {
        }
    }
}
