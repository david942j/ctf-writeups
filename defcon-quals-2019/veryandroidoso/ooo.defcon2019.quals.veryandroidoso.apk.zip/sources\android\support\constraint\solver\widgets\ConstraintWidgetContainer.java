package android.support.constraint.solver.widgets;

import android.support.constraint.solver.LinearSystem;
import android.support.constraint.solver.Metrics;
import android.support.constraint.solver.widgets.ConstraintAnchor.Type;
import android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ConstraintWidgetContainer extends WidgetContainer {
    private static final boolean DEBUG = false;
    static final boolean DEBUG_GRAPH = false;
    private static final boolean DEBUG_LAYOUT = false;
    private static final int MAX_ITERATIONS = 8;
    private static final boolean USE_SNAPSHOT = true;
    int mDebugSolverPassCount;
    public boolean mGroupsWrapOptimized;
    private boolean mHeightMeasuredTooSmall;
    ChainHead[] mHorizontalChainsArray;
    int mHorizontalChainsSize;
    public boolean mHorizontalWrapOptimized;
    private boolean mIsRtl;
    private int mOptimizationLevel;
    int mPaddingBottom;
    int mPaddingLeft;
    int mPaddingRight;
    int mPaddingTop;
    public boolean mSkipSolver;
    private Snapshot mSnapshot;
    protected LinearSystem mSystem;
    ChainHead[] mVerticalChainsArray;
    int mVerticalChainsSize;
    public boolean mVerticalWrapOptimized;
    public List<ConstraintWidgetGroup> mWidgetGroups;
    private boolean mWidthMeasuredTooSmall;
    public int mWrapFixedHeight;
    public int mWrapFixedWidth;

    public String getType() {
        return "ConstraintLayout";
    }

    public boolean handlesInternalConstraints() {
        return false;
    }

    public void fillMetrics(Metrics metrics) {
        this.mSystem.fillMetrics(metrics);
    }

    public ConstraintWidgetContainer() {
        this.mIsRtl = false;
        this.mSystem = new LinearSystem();
        this.mHorizontalChainsSize = 0;
        this.mVerticalChainsSize = 0;
        this.mVerticalChainsArray = new ChainHead[4];
        this.mHorizontalChainsArray = new ChainHead[4];
        this.mWidgetGroups = new ArrayList();
        this.mGroupsWrapOptimized = false;
        this.mHorizontalWrapOptimized = false;
        this.mVerticalWrapOptimized = false;
        this.mWrapFixedWidth = 0;
        this.mWrapFixedHeight = 0;
        this.mOptimizationLevel = 7;
        this.mSkipSolver = false;
        this.mWidthMeasuredTooSmall = false;
        this.mHeightMeasuredTooSmall = false;
        this.mDebugSolverPassCount = 0;
    }

    public ConstraintWidgetContainer(int i, int i2, int i3, int i4) {
        super(i, i2, i3, i4);
        this.mIsRtl = false;
        this.mSystem = new LinearSystem();
        this.mHorizontalChainsSize = 0;
        this.mVerticalChainsSize = 0;
        this.mVerticalChainsArray = new ChainHead[4];
        this.mHorizontalChainsArray = new ChainHead[4];
        this.mWidgetGroups = new ArrayList();
        this.mGroupsWrapOptimized = false;
        this.mHorizontalWrapOptimized = false;
        this.mVerticalWrapOptimized = false;
        this.mWrapFixedWidth = 0;
        this.mWrapFixedHeight = 0;
        this.mOptimizationLevel = 7;
        this.mSkipSolver = false;
        this.mWidthMeasuredTooSmall = false;
        this.mHeightMeasuredTooSmall = false;
        this.mDebugSolverPassCount = 0;
    }

    public ConstraintWidgetContainer(int i, int i2) {
        super(i, i2);
        this.mIsRtl = false;
        this.mSystem = new LinearSystem();
        this.mHorizontalChainsSize = 0;
        this.mVerticalChainsSize = 0;
        this.mVerticalChainsArray = new ChainHead[4];
        this.mHorizontalChainsArray = new ChainHead[4];
        this.mWidgetGroups = new ArrayList();
        this.mGroupsWrapOptimized = false;
        this.mHorizontalWrapOptimized = false;
        this.mVerticalWrapOptimized = false;
        this.mWrapFixedWidth = 0;
        this.mWrapFixedHeight = 0;
        this.mOptimizationLevel = 7;
        this.mSkipSolver = false;
        this.mWidthMeasuredTooSmall = false;
        this.mHeightMeasuredTooSmall = false;
        this.mDebugSolverPassCount = 0;
    }

    public void setOptimizationLevel(int i) {
        this.mOptimizationLevel = i;
    }

    public int getOptimizationLevel() {
        return this.mOptimizationLevel;
    }

    public boolean optimizeFor(int i) {
        return (this.mOptimizationLevel & i) == i ? USE_SNAPSHOT : false;
    }

    public void reset() {
        this.mSystem.reset();
        this.mPaddingLeft = 0;
        this.mPaddingRight = 0;
        this.mPaddingTop = 0;
        this.mPaddingBottom = 0;
        this.mWidgetGroups.clear();
        this.mSkipSolver = false;
        super.reset();
    }

    public boolean isWidthMeasuredTooSmall() {
        return this.mWidthMeasuredTooSmall;
    }

    public boolean isHeightMeasuredTooSmall() {
        return this.mHeightMeasuredTooSmall;
    }

    public boolean addChildrenToSolver(LinearSystem linearSystem) {
        addToSolver(linearSystem);
        int size = this.mChildren.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) this.mChildren.get(i);
            if (constraintWidget instanceof ConstraintWidgetContainer) {
                DimensionBehaviour dimensionBehaviour = constraintWidget.mListDimensionBehaviors[0];
                DimensionBehaviour dimensionBehaviour2 = constraintWidget.mListDimensionBehaviors[1];
                if (dimensionBehaviour == DimensionBehaviour.WRAP_CONTENT) {
                    constraintWidget.setHorizontalDimensionBehaviour(DimensionBehaviour.FIXED);
                }
                if (dimensionBehaviour2 == DimensionBehaviour.WRAP_CONTENT) {
                    constraintWidget.setVerticalDimensionBehaviour(DimensionBehaviour.FIXED);
                }
                constraintWidget.addToSolver(linearSystem);
                if (dimensionBehaviour == DimensionBehaviour.WRAP_CONTENT) {
                    constraintWidget.setHorizontalDimensionBehaviour(dimensionBehaviour);
                }
                if (dimensionBehaviour2 == DimensionBehaviour.WRAP_CONTENT) {
                    constraintWidget.setVerticalDimensionBehaviour(dimensionBehaviour2);
                }
            } else {
                Optimizer.checkMatchParent(this, linearSystem, constraintWidget);
                constraintWidget.addToSolver(linearSystem);
            }
        }
        if (this.mHorizontalChainsSize > 0) {
            Chain.applyChainConstraints(this, linearSystem, 0);
        }
        if (this.mVerticalChainsSize > 0) {
            Chain.applyChainConstraints(this, linearSystem, 1);
        }
        return USE_SNAPSHOT;
    }

    public void updateChildrenFromSolver(LinearSystem linearSystem, boolean[] zArr) {
        zArr[2] = false;
        updateFromSolver(linearSystem);
        int size = this.mChildren.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) this.mChildren.get(i);
            constraintWidget.updateFromSolver(linearSystem);
            if (constraintWidget.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.getWidth() < constraintWidget.getWrapWidth()) {
                zArr[2] = USE_SNAPSHOT;
            }
            if (constraintWidget.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.getHeight() < constraintWidget.getWrapHeight()) {
                zArr[2] = USE_SNAPSHOT;
            }
        }
    }

    public void setPadding(int i, int i2, int i3, int i4) {
        this.mPaddingLeft = i;
        this.mPaddingTop = i2;
        this.mPaddingRight = i3;
        this.mPaddingBottom = i4;
    }

    public void setRtl(boolean z) {
        this.mIsRtl = z;
    }

    public boolean isRtl() {
        return this.mIsRtl;
    }

    public void analyze(int i) {
        super.analyze(i);
        int size = this.mChildren.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((ConstraintWidget) this.mChildren.get(i2)).analyze(i);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:70:0x0191  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x0188  */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x026f  */
    /* JADX WARNING: Removed duplicated region for block: B:113:0x0298  */
    /* JADX WARNING: Removed duplicated region for block: B:112:0x028b  */
    /* JADX WARNING: Removed duplicated region for block: B:128:0x02da  */
    /* JADX WARNING: Removed duplicated region for block: B:115:0x029b  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x0188  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x0191  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x01e2  */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x026f  */
    /* JADX WARNING: Removed duplicated region for block: B:112:0x028b  */
    /* JADX WARNING: Removed duplicated region for block: B:113:0x0298  */
    /* JADX WARNING: Removed duplicated region for block: B:115:0x029b  */
    /* JADX WARNING: Removed duplicated region for block: B:128:0x02da  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void layout() {
        int i;
        Exception e;
        boolean z;
        PrintStream printStream;
        StringBuilder stringBuilder;
        int i2;
        int i3 = this.mX;
        int i4 = this.mY;
        int max = Math.max(0, getWidth());
        int max2 = Math.max(0, getHeight());
        this.mWidthMeasuredTooSmall = false;
        this.mHeightMeasuredTooSmall = false;
        if (this.mParent != null) {
            if (this.mSnapshot == null) {
                this.mSnapshot = new Snapshot(this);
            }
            this.mSnapshot.updateFrom(this);
            setX(this.mPaddingLeft);
            setY(this.mPaddingTop);
            resetAnchors();
            resetSolverVariables(this.mSystem.getCache());
        } else {
            this.mX = 0;
            this.mY = 0;
        }
        int i5 = 32;
        if (this.mOptimizationLevel != 0) {
            if (!optimizeFor(8)) {
                optimizeReset();
            }
            if (!optimizeFor(32)) {
                optimize();
            }
            this.mSystem.graphOptimizer = USE_SNAPSHOT;
        } else {
            this.mSystem.graphOptimizer = false;
        }
        DimensionBehaviour dimensionBehaviour = this.mListDimensionBehaviors[1];
        DimensionBehaviour dimensionBehaviour2 = this.mListDimensionBehaviors[0];
        resetChains();
        if (this.mWidgetGroups.size() == 0) {
            this.mWidgetGroups.clear();
            this.mWidgetGroups.add(0, new ConstraintWidgetGroup(this.mChildren));
        }
        int size = this.mWidgetGroups.size();
        ArrayList arrayList = this.mChildren;
        Object obj = (getHorizontalDimensionBehaviour() == DimensionBehaviour.WRAP_CONTENT || getVerticalDimensionBehaviour() == DimensionBehaviour.WRAP_CONTENT) ? 1 : null;
        Object obj2 = null;
        int i6 = 0;
        while (i6 < size && !this.mSkipSolver) {
            if (((ConstraintWidgetGroup) this.mWidgetGroups.get(i6)).mSkipSolver) {
                i = size;
            } else {
                int i7;
                Object obj3;
                if (optimizeFor(i5)) {
                    if (getHorizontalDimensionBehaviour() == DimensionBehaviour.FIXED && getVerticalDimensionBehaviour() == DimensionBehaviour.FIXED) {
                        this.mChildren = (ArrayList) ((ConstraintWidgetGroup) this.mWidgetGroups.get(i6)).getWidgetsToSolve();
                    } else {
                        this.mChildren = (ArrayList) ((ConstraintWidgetGroup) this.mWidgetGroups.get(i6)).mConstrainedGroup;
                    }
                }
                resetChains();
                i5 = this.mChildren.size();
                for (i7 = 0; i7 < i5; i7++) {
                    ConstraintWidget constraintWidget = (ConstraintWidget) this.mChildren.get(i7);
                    if (constraintWidget instanceof WidgetContainer) {
                        ((WidgetContainer) constraintWidget).layout();
                    }
                }
                Object obj4 = obj2;
                int i8 = 0;
                boolean z2 = USE_SNAPSHOT;
                while (z2) {
                    boolean z3;
                    int i9;
                    boolean z4 = z2;
                    int i10 = i8 + 1;
                    try {
                        this.mSystem.reset();
                        resetChains();
                        createObjectVariables(this.mSystem);
                        i8 = 0;
                        while (i8 < i5) {
                            obj3 = obj4;
                            try {
                                ((ConstraintWidget) this.mChildren.get(i8)).createObjectVariables(this.mSystem);
                                i8++;
                                obj4 = obj3;
                            } catch (Exception e2) {
                                e = e2;
                                z = z4;
                                e.printStackTrace();
                                printStream = System.out;
                                z4 = z;
                                stringBuilder = new StringBuilder();
                                i = size;
                                stringBuilder.append("EXCEPTION : ");
                                stringBuilder.append(e);
                                printStream.println(stringBuilder.toString());
                                if (z4) {
                                }
                                if (obj == null) {
                                }
                                i2 = i10;
                                obj4 = obj3;
                                z3 = false;
                                i10 = Math.max(this.mMinWidth, getWidth());
                                if (i10 > getWidth()) {
                                }
                                i10 = Math.max(this.mMinHeight, getHeight());
                                if (i10 > getHeight()) {
                                }
                                if (obj4 == null) {
                                }
                                i8 = i2;
                                size = i;
                            }
                        }
                        obj3 = obj4;
                        z = addChildrenToSolver(this.mSystem);
                        if (z) {
                            try {
                                this.mSystem.minimize();
                            } catch (Exception e3) {
                                e = e3;
                            }
                        }
                        z4 = z;
                        i = size;
                    } catch (Exception e4) {
                        e = e4;
                        obj3 = obj4;
                        z = z4;
                        e.printStackTrace();
                        printStream = System.out;
                        z4 = z;
                        stringBuilder = new StringBuilder();
                        i = size;
                        stringBuilder.append("EXCEPTION : ");
                        stringBuilder.append(e);
                        printStream.println(stringBuilder.toString());
                        if (z4) {
                        }
                        if (obj == null) {
                        }
                        i2 = i10;
                        obj4 = obj3;
                        z3 = false;
                        i10 = Math.max(this.mMinWidth, getWidth());
                        if (i10 > getWidth()) {
                        }
                        i10 = Math.max(this.mMinHeight, getHeight());
                        if (i10 > getHeight()) {
                        }
                        if (obj4 == null) {
                        }
                        i8 = i2;
                        size = i;
                    }
                    if (z4) {
                        updateChildrenFromSolver(this.mSystem, Optimizer.flags);
                        i9 = 2;
                    } else {
                        updateFromSolver(this.mSystem);
                        for (i7 = 0; i7 < i5; i7++) {
                            ConstraintWidget constraintWidget2 = (ConstraintWidget) this.mChildren.get(i7);
                            if (constraintWidget2.mListDimensionBehaviors[0] != DimensionBehaviour.MATCH_CONSTRAINT) {
                                size = 1;
                            } else if (constraintWidget2.getWidth() < constraintWidget2.getWrapWidth()) {
                                Optimizer.flags[2] = USE_SNAPSHOT;
                                i9 = 2;
                                break;
                            } else {
                                size = 1;
                            }
                            if (constraintWidget2.mListDimensionBehaviors[size] == DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget2.getHeight() < constraintWidget2.getWrapHeight()) {
                                i9 = 2;
                                Optimizer.flags[2] = USE_SNAPSHOT;
                                break;
                            }
                        }
                        i9 = 2;
                    }
                    if (obj == null && i10 < 8 && Optimizer.flags[i9]) {
                        i8 = 0;
                        i9 = 0;
                        size = 0;
                        while (i8 < i5) {
                            ConstraintWidget constraintWidget3 = (ConstraintWidget) this.mChildren.get(i8);
                            i2 = i10;
                            i9 = Math.max(i9, constraintWidget3.mX + constraintWidget3.getWidth());
                            size = Math.max(size, constraintWidget3.mY + constraintWidget3.getHeight());
                            i8++;
                            i10 = i2;
                        }
                        i2 = i10;
                        i8 = Math.max(this.mMinWidth, i9);
                        i10 = Math.max(this.mMinHeight, size);
                        if (dimensionBehaviour2 != DimensionBehaviour.WRAP_CONTENT || getWidth() >= i8) {
                            z3 = false;
                        } else {
                            setWidth(i8);
                            this.mListDimensionBehaviors[0] = DimensionBehaviour.WRAP_CONTENT;
                            z3 = USE_SNAPSHOT;
                            obj3 = 1;
                        }
                        if (dimensionBehaviour != DimensionBehaviour.WRAP_CONTENT || getHeight() >= i10) {
                            obj4 = obj3;
                        } else {
                            setHeight(i10);
                            this.mListDimensionBehaviors[1] = DimensionBehaviour.WRAP_CONTENT;
                            z3 = USE_SNAPSHOT;
                            obj4 = 1;
                        }
                    } else {
                        i2 = i10;
                        obj4 = obj3;
                        z3 = false;
                    }
                    i10 = Math.max(this.mMinWidth, getWidth());
                    if (i10 > getWidth()) {
                        setWidth(i10);
                        this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
                        z3 = USE_SNAPSHOT;
                        obj4 = 1;
                    }
                    i10 = Math.max(this.mMinHeight, getHeight());
                    if (i10 > getHeight()) {
                        setHeight(i10);
                        DimensionBehaviour[] dimensionBehaviourArr = this.mListDimensionBehaviors;
                        DimensionBehaviour dimensionBehaviour3 = DimensionBehaviour.FIXED;
                        z = USE_SNAPSHOT;
                        dimensionBehaviourArr[1] = dimensionBehaviour3;
                        z3 = USE_SNAPSHOT;
                        obj4 = 1;
                    } else {
                        z = USE_SNAPSHOT;
                    }
                    if (obj4 == null) {
                        if (this.mListDimensionBehaviors[0] == DimensionBehaviour.WRAP_CONTENT && max > 0 && getWidth() > max) {
                            this.mWidthMeasuredTooSmall = z;
                            this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
                            setWidth(max);
                            z3 = USE_SNAPSHOT;
                            obj4 = 1;
                        }
                        if (this.mListDimensionBehaviors[z] != DimensionBehaviour.WRAP_CONTENT || max2 <= 0 || getHeight() <= max2) {
                            z2 = z3;
                        } else {
                            this.mHeightMeasuredTooSmall = z;
                            this.mListDimensionBehaviors[z] = DimensionBehaviour.FIXED;
                            setHeight(max2);
                            z2 = USE_SNAPSHOT;
                            obj4 = 1;
                        }
                    } else {
                        z2 = z3;
                    }
                    i8 = i2;
                    size = i;
                }
                obj3 = obj4;
                i = size;
                ((ConstraintWidgetGroup) this.mWidgetGroups.get(i6)).updateUnresolvedWidgets();
                obj2 = obj3;
            }
            i6++;
            size = i;
            i5 = 32;
        }
        this.mChildren = arrayList;
        if (this.mParent != null) {
            i3 = Math.max(this.mMinWidth, getWidth());
            i4 = Math.max(this.mMinHeight, getHeight());
            this.mSnapshot.applyTo(this);
            setWidth((i3 + this.mPaddingLeft) + this.mPaddingRight);
            setHeight((i4 + this.mPaddingTop) + this.mPaddingBottom);
        } else {
            this.mX = i3;
            this.mY = i4;
        }
        if (obj2 != null) {
            this.mListDimensionBehaviors[0] = dimensionBehaviour2;
            this.mListDimensionBehaviors[1] = dimensionBehaviour;
        }
        resetSolverVariables(this.mSystem.getCache());
        if (this == getRootConstraintContainer()) {
            updateDrawPosition();
        }
    }

    public void preOptimize() {
        optimizeReset();
        analyze(this.mOptimizationLevel);
    }

    public void solveGraph() {
        ResolutionAnchor resolutionNode = getAnchor(Type.LEFT).getResolutionNode();
        ResolutionAnchor resolutionNode2 = getAnchor(Type.TOP).getResolutionNode();
        resolutionNode.resolve(null, 0.0f);
        resolutionNode2.resolve(null, 0.0f);
    }

    public void resetGraph() {
        ResolutionAnchor resolutionNode = getAnchor(Type.LEFT).getResolutionNode();
        ResolutionAnchor resolutionNode2 = getAnchor(Type.TOP).getResolutionNode();
        resolutionNode.invalidateAnchors();
        resolutionNode2.invalidateAnchors();
        resolutionNode.resolve(null, 0.0f);
        resolutionNode2.resolve(null, 0.0f);
    }

    public void optimizeForDimensions(int i, int i2) {
        if (!(this.mListDimensionBehaviors[0] == DimensionBehaviour.WRAP_CONTENT || this.mResolutionWidth == null)) {
            this.mResolutionWidth.resolve(i);
        }
        if (this.mListDimensionBehaviors[1] != DimensionBehaviour.WRAP_CONTENT && this.mResolutionHeight != null) {
            this.mResolutionHeight.resolve(i2);
        }
    }

    public void optimizeReset() {
        int size = this.mChildren.size();
        resetResolutionNodes();
        for (int i = 0; i < size; i++) {
            ((ConstraintWidget) this.mChildren.get(i)).resetResolutionNodes();
        }
    }

    public void optimize() {
        if (!optimizeFor(8)) {
            analyze(this.mOptimizationLevel);
        }
        solveGraph();
    }

    public ArrayList<Guideline> getVerticalGuidelines() {
        ArrayList arrayList = new ArrayList();
        int size = this.mChildren.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) this.mChildren.get(i);
            if (constraintWidget instanceof Guideline) {
                Guideline guideline = (Guideline) constraintWidget;
                if (guideline.getOrientation() == 1) {
                    arrayList.add(guideline);
                }
            }
        }
        return arrayList;
    }

    public ArrayList<Guideline> getHorizontalGuidelines() {
        ArrayList arrayList = new ArrayList();
        int size = this.mChildren.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) this.mChildren.get(i);
            if (constraintWidget instanceof Guideline) {
                Guideline guideline = (Guideline) constraintWidget;
                if (guideline.getOrientation() == 0) {
                    arrayList.add(guideline);
                }
            }
        }
        return arrayList;
    }

    public LinearSystem getSystem() {
        return this.mSystem;
    }

    private void resetChains() {
        this.mHorizontalChainsSize = 0;
        this.mVerticalChainsSize = 0;
    }

    /* Access modifiers changed, original: 0000 */
    public void addChain(ConstraintWidget constraintWidget, int i) {
        if (i == 0) {
            addHorizontalChain(constraintWidget);
        } else if (i == 1) {
            addVerticalChain(constraintWidget);
        }
    }

    private void addHorizontalChain(ConstraintWidget constraintWidget) {
        int i = this.mHorizontalChainsSize + 1;
        ChainHead[] chainHeadArr = this.mHorizontalChainsArray;
        if (i >= chainHeadArr.length) {
            this.mHorizontalChainsArray = (ChainHead[]) Arrays.copyOf(chainHeadArr, chainHeadArr.length * 2);
        }
        this.mHorizontalChainsArray[this.mHorizontalChainsSize] = new ChainHead(constraintWidget, 0, isRtl());
        this.mHorizontalChainsSize++;
    }

    private void addVerticalChain(ConstraintWidget constraintWidget) {
        int i = this.mVerticalChainsSize + 1;
        ChainHead[] chainHeadArr = this.mVerticalChainsArray;
        if (i >= chainHeadArr.length) {
            this.mVerticalChainsArray = (ChainHead[]) Arrays.copyOf(chainHeadArr, chainHeadArr.length * 2);
        }
        this.mVerticalChainsArray[this.mVerticalChainsSize] = new ChainHead(constraintWidget, 1, isRtl());
        this.mVerticalChainsSize++;
    }

    public List<ConstraintWidgetGroup> getWidgetGroups() {
        return this.mWidgetGroups;
    }
}
