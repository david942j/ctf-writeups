#!/bin/bash

cd `dirname $0`
sandbox-exec -f ./applepie.sb ./applepie 2>/dev/null
