#include <stdio.h>

int main() {
  puts("Hooray! A custom ELF is executed!");
  return 0;
}
