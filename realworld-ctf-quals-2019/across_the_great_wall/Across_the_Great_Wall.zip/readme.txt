## The source code ##
https://github.com/zh-explorer/shadow
https://github.com/zh-explorer/Coroutine


## The flag ##
/home/pwn/flag


## build env && remote system env ##

$ g++ --version
g++ (Ubuntu 7.4.0-1ubuntu1~18.04.1) 7.4.0

$ cmake --version
cmake version 3.10.2

$ /lib/x86_64-linux-gnu/libc.so.6
GNU C Library (Ubuntu GLIBC 2.27-3ubuntu1) stable release version 2.27.

$ cat /etc/issue
Ubuntu 18.04.3 LTS
